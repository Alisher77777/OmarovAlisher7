interface SupportHandler {
    void handleRequest(SupportRequest request);

    default void setNextHandler(SupportHandler softwareHandler) {

    }
}
class HardwareHandler implements SupportHandler {
    private SupportHandler nextHandler;

    @Override
    public void handleRequest(SupportRequest request) {
        if (request.getType().equals("Hardware")) {
            System.out.println("Hardware issue handled by Hardware team");
        } else if (nextHandler != null) {
            nextHandler.handleRequest(request);
        }
    }

    public void setNextHandler(SupportHandler nextHandler) {
        this.nextHandler = nextHandler;
    }
}

class SoftwareHandler implements SupportHandler {
    private SupportHandler nextHandler;

    @Override
    public void handleRequest(SupportRequest request) {
        if (request.getType().equals("Software")) {
            System.out.println("Software issue handled by Software team");
        } else if (nextHandler != null) {
            nextHandler.handleRequest(request);
        }
    }

    public void setNextHandler(SupportHandler nextHandler) {
        this.nextHandler = nextHandler;
    }
}

class NetworkHandler implements SupportHandler {
    private SupportHandler nextHandler;

    @Override
    public void handleRequest(SupportRequest request) {
        if (request.getType().equals("Network")) {
            System.out.println("Network issue handled by Network team");
        } else if (nextHandler != null) {
            nextHandler.handleRequest(request);
        }
    }

    public void setNextHandler(SupportHandler nextHandler) {
        this.nextHandler = nextHandler;
    }
}
class SupportRequest {
    private String type;
    private String description;
    private String priority;

    public SupportRequest(String type, String description, String priority) {
        this.type = type;
        this.description = description;
        this.priority = priority;
    }
    public String getType() {
        return type;
    }
}
public class HelpDesk {
    private SupportHandler chain;

    public HelpDesk() {
        chain = new HardwareHandler();
        SupportHandler softwareHandler = new SoftwareHandler();
        SupportHandler networkHandler = new NetworkHandler();
        chain.setNextHandler(softwareHandler);
        softwareHandler.setNextHandler(networkHandler);
    }

    public void raiseTicket(SupportRequest request) {
        chain.handleRequest(request);
    }
    public static void main(String[] args) {
        HelpDesk helpDesk = new HelpDesk();

        SupportRequest hardwareRequest = new SupportRequest("Hardware", "Monitor not working", "High");
        SupportRequest softwareRequest = new SupportRequest("Software", "Application crashing", "Medium");
        SupportRequest networkRequest = new SupportRequest("Network", "Internet connection lost", "Low");

        helpDesk.raiseTicket(hardwareRequest);
        helpDesk.raiseTicket(softwareRequest);
        helpDesk.raiseTicket(networkRequest);
    }
}
