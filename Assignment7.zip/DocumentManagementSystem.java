import java.util.HashMap;
import java.util.Map;
interface DocumentService {
    void uploadDocument(String documentName, byte[] documentContent);
    byte[] downloadDocument(String documentName);
    void deleteDocument(String documentName);
}
class RealDocumentService implements DocumentService {
    private Map<String, byte[]> documents = new HashMap<>();

    @Override
    public void uploadDocument(String documentName, byte[] documentContent) {
        documents.put(documentName, documentContent);
        System.out.println("Document '" + documentName + "' uploaded successfully");
    }

    @Override
    public byte[] downloadDocument(String documentName) {
        byte[] documentContent = documents.get(documentName);
        if (documentContent != null) {
            System.out.println("Document '" + documentName + "' downloaded successfully");
            return documentContent;
        } else {
            System.out.println("Document '" + documentName + "' not found");
            return null;
        }
    }
    @Override
    public void deleteDocument(String documentName) {
        documents.remove(documentName);
        System.out.println("Document '" + documentName + "' deleted successfully");
    }
}
class DocumentServiceProxy implements DocumentService {
    private RealDocumentService realDocumentService = new RealDocumentService();
    private Map<String, Integer> userPermissions = new HashMap<>();

    public void setUserPermissions(String username, int permissionLevel) {
        userPermissions.put(username, permissionLevel);
    }

    private boolean checkPermissions(String username, int requiredPermissionLevel) {
        Integer userPermissionLevel = userPermissions.get(username);
        return userPermissionLevel != null && userPermissionLevel >= requiredPermissionLevel;
    }

    @Override
    public void uploadDocument(String documentName, byte[] documentContent) {
        if (checkPermissions("uploadUser", 2)) { // Проверка разрешений
            realDocumentService.uploadDocument(documentName, documentContent);
        } else {
            System.out.println("Permission denied to upload document");
        }
    }

    @Override
    public byte[] downloadDocument(String documentName) {
        if (checkPermissions("downloadUser", 1)) { // Проверка разрешений
            return realDocumentService.downloadDocument(documentName);
        } else {
            System.out.println("Permission denied to download document");
            return null;
        }
    }

    @Override
    public void deleteDocument(String documentName) {
        if (checkPermissions("deleteUser", 3)) { // Проверка разрешений
            realDocumentService.deleteDocument(documentName);
        } else {
            System.out.println("Permission denied to delete document");
        }
    }
}
public class DocumentManagementSystem {
    public static void main(String[] args) {
        DocumentService documentService = new DocumentServiceProxy();

        ((DocumentServiceProxy) documentService).setUserPermissions("uploadUser", 2);
        ((DocumentServiceProxy) documentService).setUserPermissions("downloadUser", 1);
        ((DocumentServiceProxy) documentService).setUserPermissions("deleteUser", 3);

        documentService.uploadDocument("Document1", "Content1".getBytes());

        documentService.uploadDocument("Document2", "Content2".getBytes());

        byte[] content = documentService.downloadDocument("Document1");

        byte[] content2 = documentService.downloadDocument("Document2");

        documentService.deleteDocument("Document1");

        documentService.deleteDocument("Document2");
    }
}
